import React, {Component} from 'react';
import './App.css';

const Title = props => <div>{props.title}</div>

export default Title 